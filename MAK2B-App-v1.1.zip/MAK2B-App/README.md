# MAK2B – مكتوب | v1.1

تطبيق خدمات متعدد المنصات مبني بـ Expo/React Native، باستخدام الشعار الرسمي المرفق.

## ما تم تثبيته في هذه النسخة
- Android + iOS من قاعدة برمجية واحدة.
- هوية MAK2B الداكنة مع الذهبي المعتق والعاجي.
- الشعار الرسمي كما هو دون إعادة تصميم.
- واجهة عميل بدون لوحة إدارة ضخمة في المرحلة الأولى.
- الأقسام الثمانية للخدمات.
- نموذج طلب ديناميكي.
- تحديد الموقع وفتح الخرائط.
- إرفاق الصور وتسجيل عددها ضمن الطلب.
- إنشاء رقم طلب فريد محليًا.
- حفظ الطلبات على الجهاز.
- تجهيز رسالة WhatsApp كاملة ومشفرة بشكل صحيح بالعربية إلى 07801011014.
- صفحة طلباتي.
- صفحة مكتوب والحساب.
- بنية قابلة للتوسع لاحقًا إلى قاعدة بيانات سحابية وPush Notifications وWhatsApp Business API ولوحة إدارة.

## تشغيل المشروع
```bash
npm install
npx expo start
```

## بناء Android / iOS للإنتاج
بعد تثبيت EAS CLI وتسجيل الدخول بحساب Expo:
```bash
npx eas build:configure
npx eas build --platform android --profile production
npx eas build --platform ios --profile production
```

ثم للنشر:
```bash
npx eas submit --platform android --profile production
npx eas submit --platform ios --profile production
```

يتطلب نشر iOS حساب Apple Developer، ويتطلب النشر على Google Play حساب Google Play Console.

## ملاحظة WhatsApp
التطبيق يفتح WhatsApp ويجهز الرسالة تلقائيًا، لكن إرسال الرسالة يتم بتأكيد المستخدم. إرسال الصور أو الرسائل في الخلفية يحتاج WhatsApp Business Platform/API وتكاملًا خادميًا.
